Student Marks Data Analysis System
--------------------------------
This project performs data analysis on student marks using pure Python.

Files:
- main.py : Main program (menu-driven)
- students.csv : Student data file

How to Run:
1. Keep both files in same folder
2. Run: python main.py
